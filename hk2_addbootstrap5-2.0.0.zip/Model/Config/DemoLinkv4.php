<?php

namespace HK2\AddBootstrap5\Model\Config;

use Magento\Framework\UrlInterface;
use Magento\Store\Model\StoreManagerInterface;

class DemoLinkv4 implements \Magento\Config\Model\Config\CommentInterface
{
    private $urlInterface;
    private $_storeManager;

    public function __construct(UrlInterface $urlInterface, StoreManagerInterface $storeManagerInterface)
    {
        $this->urlInterface = $urlInterface;
        $this->_storeManager = $storeManagerInterface;
    }

    public function getCommentText($elementValue)
    {
        $base_url =            $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_WEB);
        $url = $base_url . 'addbootstrap/demo4';
        return '<a href="' . $url . '"target="_blank">' . $url . '</a>.';
    }
}
