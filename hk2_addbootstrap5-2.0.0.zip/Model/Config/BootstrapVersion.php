<?php

namespace HK2\AddBootstrap5\Model\Config;

class BootstrapVersion extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    protected $_options;

    /**
     * @return array[]
     */
    public function getAllOptions()
    {
        if ($this->_options === null) {
            $optionArray = $this->getBoostrapVersion();
            $labels = array_column($optionArray, 'label');
            $values = array_column($optionArray, 'value');
            $this->_options = array_combine($values, $labels);
        }
        return $this->_options;
    }

    /**
     * @return array[]
     */
    final public function toOptionArray()
    {
        $optionArray = $this->getBoostrapVersion();
        $labels = array_column($optionArray, 'label');
        $values = array_column($optionArray, 'value');
        return array_combine($values, $labels);
    }

    /**
     * @return array[]
     */
    public function getBoostrapVersion(): array
    {
        return array(
            array('value' => '5.2.3', 'label' => __('Bootstrap5.2.3')),
            array('value' => '5.1.3', 'label' => __('Bootstrap5.1.3')),
            array('value' => '4.6.2', 'label' => __('Bootstrap4.6.2'))
        );
    }
}