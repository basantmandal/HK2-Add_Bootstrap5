<?php

namespace HK2\AddBootstrap5\Block;

/**
 * Block Index Class
 */
class Index extends \Magento\Framework\View\Element\Template
{
}