<?php

namespace HK2\AddBootstrap5\Block;

/**
 * Block Demo Class
 */

class Demo extends \Magento\Framework\View\Element\Template
{
}