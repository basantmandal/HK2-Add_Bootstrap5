<?php

namespace HK2\AddBootstrap5\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{
    /**
     * @var ScopeConfigInterface
     */
    private ScopeConfigInterface $_scopeConfig;

    // Section & Group
    private const HK2_ADDBOOTSTRAP5_SECTION_01 = 'hk2_addbootstrap5_section1/';
    private const HK2_ADDBOOTSTRAP5_GROUP_01 = 'hk2_addbootstrap5_section1_group1/';
    private const HK2_ADDBOOTSTRAP5_GROUP_02 = 'hk2_addbootstrap5_section1_group2/';

    // Configuration Variable
    private const HK2_ADDBOOTSTRAP5_CONFIG_ENABLE = 'hk2_addBootstrap5_enable';
    private const HK2_ADDBOOTSTRAP5_CONFIG_VERSION = 'hk2_addBootstrap5_select_bootstrap_version';
    private const HK2_ADDBOOTSTRAP5_CONFIG_DEBUG = 'hk2_addBootstrap5_debug';

    // Configurations Data
    private const HK2_ADDBOOTSTRAP5_ENABLE_PATH = self::HK2_ADDBOOTSTRAP5_SECTION_01 . self::HK2_ADDBOOTSTRAP5_GROUP_01 . self::HK2_ADDBOOTSTRAP5_CONFIG_ENABLE;
    private const HK2_ADDBOOTSTRAP5_VERSION = self::HK2_ADDBOOTSTRAP5_SECTION_01 . self::HK2_ADDBOOTSTRAP5_GROUP_02 . self::HK2_ADDBOOTSTRAP5_CONFIG_VERSION;
    private const HK2_ADDBOOTSTRAP5_DEBUG = self::HK2_ADDBOOTSTRAP5_SECTION_01 . self::HK2_ADDBOOTSTRAP5_GROUP_02 . self::HK2_ADDBOOTSTRAP5_CONFIG_DEBUG;

    /**
     * Construct
     * 
     * @param Context $context
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(Context $context, ScopeConfigInterface $scopeConfig)
    {
        parent::__construct($context);
        $this->_scopeConfig = $scopeConfig;
    }

    /**
     * Returns Is Enabled Data from Configuration
     *
     * @return mixed
     */
    public function isEnabled()
    {
        return $this->_scopeConfig->getValue(self::HK2_ADDBOOTSTRAP5_ENABLE_PATH, ScopeInterface::SCOPE_STORE);
    }

    /**
     * Returns Bootstrap Version Data from Configuration
     *
     * @return mixed
     */
    public function getBootstrapVersion()
    {
        return $this->_scopeConfig->getValue(self::HK2_ADDBOOTSTRAP5_VERSION, ScopeInterface::SCOPE_STORE);
    }

    /**
     * Returns Is Debug Data from Configuration
     * 
     * @return mixed
     */
    public function isDebugEnabled()
    {
        return $this->_scopeConfig->getValue(self::HK2_ADDBOOTSTRAP5_DEBUG, ScopeInterface::SCOPE_STORE);
    }

    /**
     * Returns Generated Bootstrap CSS CDN Link
     *
     * @param  [type] $version
     *
     * @return mixed
     */
    public function generateBootstrapCdnLink($version)
    {

        // Bootstrap 5.2.3
        $bootstrap_5_2_3_jsdelivr = [
            'style' => '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous" />'
        ];

        // Bootstrap 5.1.3
        $bootstrap_5_1_3_jsdelivr = [
            'style' => '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">'
        ];

        // Bootstrap 4.6.2
        $bootstrap_4_6_2_jsdelivr = [
            'style' => '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha512-iQQV+nXtBlmS3XiDrtmL+9/Z+ibux+YuowJjI4rcpO7NYgTzfTOiFNm09kWtfZzEB9fQ6TwOVc8lFVWooFuD/w==" crossorigin="anonymous" referrerpolicy="no-referrer" />'
        ];

        switch ($version) {
            case '5.1.3':
                $link = $bootstrap_5_1_3_jsdelivr;
                break;
            case '4.6.2':
                $link = $bootstrap_4_6_2_jsdelivr;
                break;
            default:
                $link = $bootstrap_5_2_3_jsdelivr;
        }
        return $link;
    }
}