require(['jquery', 'bootstrap462'], function ($) {
    $(window).load(function () {
        // Write your custom code if needed
    });
});