require(['jquery', 'bootstrap523'], function ($) {
    $(window).load(function () {
        // Write your custom code if needed
    });
});